
package cfa_dadecounty_codeofordinances;


import java.io.BufferedReader;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.Jsoup;







/**
 *
 * @author Cristhian
 */
public class SectionRetrieval {

    public String line;
    String section;
    String History;
    String Prefix;
    String experation;
    
    StringBuilder sb = new StringBuilder();
    BufferedReader buffer;
    
    
    int mainSec = 0;
    String startingSection = "";
    String SBline;
    ArrayList<String> textSections = new ArrayList<>();
    ArrayList<String[]> r = new ArrayList<>();
    String[] c;
    

    public SectionRetrieval(ArrayList list, String source, ArrayList titles) {
        try {
            StringReader s = new StringReader(source);
            buffer = new BufferedReader(s);
            line = buffer.readLine();
            
                
            int j = list.size() - 1;
            if (!list.isEmpty())
            {
            while (!line.contains(list.get(j).toString())) {
                line = buffer.readLine();
            }

            
           //
            //goes through titles
            for (int i = 0; i <= list.size(); i++) {
                 
                if (i + 1 < list.size()) 
                {
                    System.out.println("<catch_line>"+titles.get(i).toString()+"</catch_line>");
                      line = buffer.readLine();
                      //System.out.println("\t<section_number></section_number>");
                     
                    //read until next title
                    while (!line.contains(list.get(i + 1).toString())) 
                    {
                        
                     
                         sb.append(line + "\n");
                         line = buffer.readLine();
                         
                    }
                    
                    
                   textTrim(sb);
                  determineTextOrder(textSections);
                } 
                if (i == list.size())
                {
                    System.out.println("<catch_line>"+titles.get(titles.size()-1).toString()+"</catch_line>");
                    line = buffer.readLine();
                    while (!line.contains("/html")) 
                    {
                        
                     
                         sb.append(line + "\n");
                         line = buffer.readLine();
                         
                    }
                    
                    textTrim(sb);
                  determineTextOrder(textSections);
                }
                
                  System.out.println("");
                 sb.setLength(0);
                 textSections.clear();
            }
            }
            else
            {
                while(!line.contains("h0"))
                    {
                        line = buffer.readLine();
                    }
                while(line != null)
                {
                    sb.append(line + "\n");
                    line = buffer.readLine();
                    
                }
               textTrim(sb);
                System.out.println("<catch_line>"+"</catch_line>");
               determineTextOrder(textSections);
            }
             System.out.println("</law>");
        } catch (Exception e) {
            e.printStackTrace();
        }
    

    }
    
    private void textTrim(StringBuilder sb){//>[\?\!\[\@\'\,\&\]]?[\n\r]?\s+?.[A-Za-z][A-Za-z](.*?)([^<]*)<|>[A-Za-z].?([A-Za-z0-9].?(.*?)([^<]*))<|>\(([A-Za-z0-9]\\)([^<]*))<|>(\(.+)  >(\\(.+)
        String regex2 = ">[\\?\\!\\[\\@\\'\\,\\&\\]]?[\\n\\r]?\\s+?[A-Za-z][A-Za-z](.*?)([^<]*)<|>[A-Za-z].?([A-Za-z0-9].?(.*?)([^<]*))<|>\\(([A-Za-z0-9]\\)([^<]*))<|(?s)>\\(.+?<|\\s(?s)<table.+?</table>";
        Pattern patternInfo = Pattern.compile(regex2);
        Matcher matcher2 = patternInfo.matcher(sb.toString().replaceAll("[^\\x00-\\x7F]", "")); //remove all non ASCII chars);


        //find matches to regex between tags
        while (matcher2.find()) {
        
               
                String Match = matcher2.group();
               // System.out.println(Match);
                
                    textSections.add(Match.substring(1, matcher2.group().length() - 1));

        }
        
    }

    private void determineTextOrder(ArrayList text)
    {
        System.out.println("<text>");
        int count = 0; 
        try {
        for (int i = 0; i <= text.size(); i++)
        {
            
//            if (text.get(i).toString().matches("[A-Za-z]+?."))
//            {
//                System.out.println(text.get(i).toString());
//            }

            if (text.get(i).toString().matches("[\\(][A-Za-z][\\)]"))
            {
                System.out.println("***********************************************************");
                System.out.println(text.get(i));
                i++;
            try{
                while (!text.get(i).toString().matches("[\\(][A-Za-z][\\)]"))
                {
                   if (text.get(i).toString().matches("\\([0-9]\\)"))
                   {
                    System.out.println(text.get(i));
                                              

                   }
                   if (text.get(i).toString().matches("[A-Za-z]+?."))
            {
                System.out.println(text.get(i).toString());
            }
                   
                } 
             System.out.println("***********************************************************");
                
            }catch (Exception e)
            {
                
            }
            }
            
                
                
//            if (text.get(i).toString().matches("\\([0-9]\\)"))
//                
//            if (text.get(i).toString().contains("FOOTNOTE"))
//                
//            if(text.get(i).toString().contains("<table"))
//                
//            if (text.get(i).toString().contains("(Ord."))
//       
        }
    }
    
catch (Exception e)
    { 
    }

    }
    
}
