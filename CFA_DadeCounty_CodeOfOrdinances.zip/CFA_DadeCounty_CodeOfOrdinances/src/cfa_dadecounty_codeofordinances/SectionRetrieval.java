package cfa_dadecounty_codeofordinances;

import java.io.BufferedReader;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


/**
 *
 * @author Cristhian
 */
public class SectionRetrieval {

    private String line;
    private StringBuilder sb = new StringBuilder();
    private BufferedReader buffer;
    private ArrayList<String> textSections = new ArrayList<>();
    private String startingSection;
    private String[] c;
    private String History;
    private int size = 0;
    private StringBuilder result = new StringBuilder();

    public SectionRetrieval(ArrayList sections, String source, ArrayList titles) {
        try {
            StringReader s = new StringReader(source);
            buffer = new BufferedReader(s);
            line = buffer.readLine();
            

            int j = sections.size() - 1;
            if (!sections.isEmpty()) {
                while (!line.contains(sections.get(j).toString())) {
                    line = buffer.readLine();
                }
                //goes through titles
                for (int i = 0; i <= sections.size(); i++) {

                    if (i + 1 < sections.size()) {
                        result.append("<catch_line>" + titles.get(i).toString() + "</catch_line>" + "\n");
                        
                        line = buffer.readLine();
                        
                        //read until next title
                        while (!line.contains(sections.get(i + 1).toString())) {
                            sb.append(line + "\n");
                            line = buffer.readLine();
                           
                            
                        }
                        
                        textTrim(sb);
                        determineTextOrder(textSections);
                    }
                    if (i == sections.size()) {
                        result.append("<catch_line>" + titles.get(titles.size() - 1).toString() + "</catch_line>" + "\n");
                        line = buffer.readLine();
                        while (!line.contains("/html")) {
                            sb.append(line + "\n");
                            line = buffer.readLine();
                        }

                        textTrim(sb);
                        determineTextOrder(textSections);
                    }

                    result.append("\n");
                    sb.setLength(0);
                    textSections.clear();
                }
            } else {
                while (!line.contains("crumb")) {
                    line = buffer.readLine();
                }
                while (line != null) {
                    sb.append(line + "\n");
                    line = buffer.readLine();

                }
                textTrim(sb);
                result.append("<catch_line>" + "</catch_line>" + "\n");
                determineTextOrder(textSections);
            }

            result.append("</law>" + "\n");
        } catch (Exception e) {
            //result.append(sections.toString());
            //result.append(titles.toString());
            e.printStackTrace();
        }

    }

    private void textTrim(StringBuilder sb) {//>[\?\!\[\@\'\,\&\]]?[\n\r]?\s+?[A-Za-z][A-Za-z](.*?)([^<]*)<|>\"?[A-Za-z].?([A-Za-z0-9].?(.*?)([^<]*))<|>\(([A-Za-z0-9]\)([^<]*))<|(?s)>\(.+?<|\s(?s)<table.+?</table>
String html = sb.toString();
        Document doc = Jsoup.parse(html);
        
        Elements para = doc.select("p, table");
       // Elements tables = doc.select("table");
        for (Element ptext : para)
        {
//            textSections.add(ptext.toString());
            Elements lineText = ptext.select("p");
            for (Element lText : lineText)
                textSections.add(lText.text());
            Elements tableText = ptext.select("table");
            for (Element tText : tableText)
                textSections.add(tText.toString());
        }
        
        
        
        //        String regex2 = ">[0-9].\\.?([^<]*)<|>[\\?\\!\\[\\@\\'\\,\\\"\\&\\]]?[\\n\\r]?\\s+?[A-Za-z0-9][A-Za-z0-9](.*?)([^<]*)<|>\\\"?[A-Za-z].?([A-Za-z0-9].?(.*?)([^<]*))<|>\\(([A-Za-z0-9]\\)([^<]*))<|(?s)>\\(.+?<|>\\(.+?\\)|\\s(?s)<table.+?</table>";
//        Pattern patternInfo = Pattern.compile(regex2);
//        Matcher matcher2 = patternInfo.matcher(sb.toString().replaceAll("[^\\x00-\\x7F]", "")); //remove all non ASCII chars);
//
//        //find matches to regex between tags
//        while (matcher2.find()) {
//            String Match = matcher2.group();
//            textSections.add(Match.substring(1, matcher2.group().length() - 1));
//        }
    }

    private void determineTextOrder(ArrayList<String> text) {
        result.append("<text>" + "\n");
        //array elements are coupled in increments of 2
        //fix </section> tag
        for(int i = 0 ; i < text.size() ; i++)
       {
           //result.append(text.get(i).toString());
            if(i==0){continue;} //skip incomplete title
            if (text.get(i).toString().contains("<table"))
                   {
                       int columnWidth = 20;
                       //result.append("**************************");
                       String html = text.get(i).toString();
                       Document doc = Jsoup.parse(html);
                       for (Element table : doc.select("table")) 
                       {
                           
                        for (Element row : table.select("tr")) 
                        {
                            
                            result.append("\n");
                            for  (Element tds : row.select("td"))
                            { 
                             
                                c = (tds.text()).split("\\,");
                            result.append(String.format("%-" + columnWidth + "s", "\t"+Arrays.toString(c)));
                                size++;
                            }
                            
                            
                            
                        }   
                           result.append("\n");
                          
        
                        }
                   result.append("\n");
                   }
            else if(text.get(i).matches("\\([0-9]{1,}\\)|[0-9]{1,}\\.?")){
                result.append("<section prefix = " + text.get(i) + ">" + "\n");
                result.append(text.get(i+1)+ "\n");
                result.append("</section>"+ "\n");
                i++;
            }
            else if(text.get(i).matches("\\([A-Za-z]{1,}\\)|^[A-Za-z][A-Za-z]?[A-Za-z]?\\.$")){
                if(i != 1 || i == text.size())
                    result.append("</section>"+ "\n");
                result.append("<section prefix = " + text.get(i) + ">" + "\n");
                if(i < text.size()-1)
                    result.append(text.get(i+1)+ "\n");
                i++;
            }
            else if (text.get(i).toString().contains("Ord."))
                      {
                       
                           History = text.get(i).toString().trim();
                           result.append("<history>" + History + "</history>"+ "\n");
                       
                      }
            else if (text.get(i).toString().contains("FOOTNOTE"))
                   {
                       
                           i = text.size()-1;
                   }
            else if(i == text.size()-1){
                result.append("</section>"+ "\n");
            }
            else{
                result.append(text.get(i)+ "\n");
            }
        }
        
        result.append("</text>"+ "\n");
    }
    public StringBuilder getResults()
    {
        return result;
    }

}
