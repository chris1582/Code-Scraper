package cfa_dadecounty_codeofordinances;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Hierarchy {
    
     
    private URL url;
    private String source;
    private InputStream stream;
    private BufferedReader buf;
    private StringBuilder sb;
    private String src;
    private Pattern checkRegex;
    private String regex;
    private Matcher rmatcher;
    String test;
    String level;
    private String baseURL;
    String title = "";
    String sectionNum = "";
    String parentTitle = "";
    ArrayList<String> listOfSections = new ArrayList<String>();
    String links;
    String pageTitle;
    ArrayList<String> listofTitles = new ArrayList<String>();
    SectionRetrieval sr;
     String res;

    
    public Hierarchy(String Source) {
        this.source = Source; 
        baseURL = "http://library.municode.com/HTML/10620/";
        level = "";
        getSrc();
        getLevel();
        trimLinksInfo();
        getParentTitleLine();
        getPageTitle();
        getSectionInfo();
        createXML();
        
        
        
    }
    //gets page information from source page
    public void getSrc() {
        try {
            //stream = url.openStream();
            URL site = new URL(source);
            URLConnection cod = site.openConnection();
            buf = new BufferedReader(new InputStreamReader(cod.getInputStream(), "UTF-8"));
            sb = new StringBuilder();
            while (true) {
                int data = buf.read();
                if (data == -1) break;
                else sb.append((char) data);
            }
            src = sb.toString();
        } catch (Exception e) {}
    }
    // Trims lines that contain links and titles
    public void trimLinksInfo(){//>\"?[A-Za-z].?([A-Za-z0-9].?(.*?)([^<]*))<
        //<a(\\\"?|\\#?)(?!.*(javascript|target|html#|book|ref\\\\.)).+(\\\"?)>(?!.*(gt;))\\\"?[A-Za-z].?([A-Za-z0-9].?(.*?)([^<]*))</a>
        regex = "(?!.*(gt;))<a(\\\"?|\\#?)(?!.*(javascript|target|html#|book|crumb|ref\\.)).+(\\\"?)>\\\"?[A-Za-z].?([A-Za-z0-9].?(.*?)([^<]*))</a>";
        checkRegex = Pattern.compile(regex);
        rmatcher = checkRegex.matcher(sb.toString());
        while(rmatcher.find()){
            links = getLinks(rmatcher.group().trim());
            title = getTitle(rmatcher.group().trim());
            
            sectionNum = getSectionNum(title);
            listOfSections.add(sectionNum);
            
        }
    }
    //retrive links form line
    public String getLinks(String s){
        String regex2 = "(?!.*(f=)|([A-Za-z])|(/))([/level?]|[\\#?])[A-Za-z].+?[\\\"?]";
        Pattern checkRegex2 = Pattern.compile(regex2);
        Matcher rmatcher2 = checkRegex2.matcher(s);
        while(rmatcher2.find()){
            if(rmatcher2.group().trim().substring(0,rmatcher2.group().length()-1).charAt(0) == '#')
            {
                return url + rmatcher2.group().trim().substring(0,rmatcher2.group().length()-1);
            }
            else
                return baseURL + rmatcher2.group().trim().substring(1,rmatcher2.group().length()-1);
        }
        return "";
    }
    //get section Titles from Page 
    public String getTitle(String s){ 
        
        String html = s;
        //outputFile.println(s);
        Document doc = Jsoup.parse(html);
        for (Element title : doc.select("a")) 
        {
            //outputFile.println(title.text());
            listofTitles.add(title.text());
            return title.text();
        }
        return "";
//        String regex2 = "(>[A-Za-z\\[].+?([<]))|(>[A-Za-z\\[](.+?)(.+))";
//        Pattern pattern = Pattern.compile(regex2);
//        Matcher matcher = pattern.matcher(s);
//        
//        if(matcher.find())
//        {
//            listofTitles.add(matcher.group().trim().substring(1));
//           return matcher.group().trim().substring(1);
//        }
//        
//        return "";
    }
    //get the section number for the page
    public String getSectionNum(String s)
    {
        //[Ss][Ee][Cc][Tt]?[Ii]?[Oo]?[Nn]?[\\.]\\s\\d.+?\\.?\\d+\\.?
        //System.out.println(s);
        String regex = "[Ss][Ee][Cc][Tt]?[Ii]?[Oo]?[Nn]?[\\.]?\\s\\d.+?\\.?\\d+\\.?";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(s);
        if(matcher.find())
        {
            return matcher.group().trim();
            //outputFile.println(sectionNum);
        }
        return "";
    }
    //gets line that contains Parent Title
    public void getParentTitleLine()
    {
        String src = sb.toString();
        String regex = "([Mm][Ee][Tt][Aa]\\s.+?\\=\\\")([Pp][Aa][Rr].+)(\\\")";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(src);
        String line = "";
        if(matcher.find())
        {
           line = matcher.group().trim();
           getParentTitle(line);
        }
    }
    //Gets the Parent Title: <unit></unit>
    public void getParentTitle(String s)
    {
       
        String regex = "[Tt][Ee][Nn][Tt]\\=\\\"?.+";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(s);
        if(matcher.find())
        {
            parentTitle = matcher.group().trim().substring(6, matcher.group().length()-1);
            //outputFile.println(parentTitle);
        }
           
    }
    //gets the Page Title
    public void getPageTitle()
    {
        
        String html = sb.toString();
        
        Document doc = Jsoup.parse(html);
        for (Element title : doc.select("title")){
            if (title.text().trim().replace("\n", "").replace(",","").replace(" ", "_").length()< 40)
                pageTitle= title.text().trim().replace("\n", "").replace(",","").replace(" ", "_");
            else
               pageTitle= title.text().trim().replace("\n", "").replace(",","").replace(" ", "_").substring(0, 40); 
        }
            
      
//        String src = sb.toString(); //(\\<title>)(\\n\\r)?(.+)(\\n\\r)?\\s+?(\\<.?title>)
//        String regex = "(?s)(<title>)(.+)(\\<.?title>)";
//        Pattern pattern = Pattern.compile(regex);
//        Matcher matcher = pattern.matcher(src);
//        if(matcher.find())
//            pageTitle = matcher.group().substring(7, matcher.group().length()-8).trim().replace("\n", "").replace("  ", "");;
   }
    
    
    //gets level from page
    public void getLevel(){
        String src = sb.toString();
        String regex2 = "crumb.+";
        Pattern pattern = Pattern.compile(regex2);
        Matcher matcher = pattern.matcher(src);
        level = "";
        if(matcher.find()){
            level = matcher.group().trim();
        }
        
        String [] test = level.split("crumb");
        
        
        //outputFile.println(test[test.length-1]);
        regex2 = "level[0-9]{1}";
        pattern = Pattern.compile(regex2);
        matcher = pattern.matcher(test[test.length-1]);
        while(matcher.find()){
            level = matcher.group().trim();
            //outputFile.println(level.substring(5, level.length()));
        }
    }
    
    public void getSectionInfo()
    {
        System.out.println(pageTitle);
        System.out.println(listOfSections);
        System.out.println(listofTitles);
         sr = new SectionRetrieval(listOfSections, src, listofTitles);
    }
    private void createXML()
    {
        try{
            String fileName = pageTitle.replace(".", "_");
        File file = new File("C:\\Users\\Cristhian\\Desktop\\result\\"+fileName+".xml");
        FileWriter fwriter = new FileWriter(file);
        PrintWriter outputFile = new PrintWriter(fwriter);
        outputFile.println("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
        outputFile.println("<law>");
        outputFile.println("\t<structure>");
        outputFile.println("\t\t<unit label=\"title\" identifier=\""+ sectionNum+ "\" order_by=\""+sectionNum+"\" level=\"\">"+parentTitle+"</unit>");
        outputFile.println("\t\t<unit label=\"chapter\" identifier=\""+ sectionNum+ "\" order_by=\""+sectionNum+"\" level=\"\">"+pageTitle+"</unit>");
        outputFile.println("\t</structure>");
        
        //res = sr.getResults().toString();
        
        
        outputFile.write(sr.getResults().toString());
        outputFile.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        
    }
    
    

    
}
